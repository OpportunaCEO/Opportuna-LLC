// Simulated React app bundle (placeholder)
console.log('App loaded');